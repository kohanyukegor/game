import pygame
from pygame.locals import *

size=width,heigh=[600,600]
road_w=int(width/1.6)
pygame.init()
roadmark_w=int(width/80)
running=True
screen = pygame.display.set_mode((size))
pygame.display.set_caption("Cars")
screen.fill((60,220,0))

pygame.draw.rect(screen,
    (50,50,50),
    (width/2-road_w,0,road_w,heigh)
)
pygame.draw.rect(
    screen,
    (255,240,60),
    (width/2-roadmark_w/2,0,roadmark_w,heigh))
pygame.draw.rect(
    screen,
    (255,255,255),
    (width/2-roadmark_w*2,0,roadmark_w,heigh))
pygame.draw.rect(
    screen,
    (255,255,255),
    (width/2-roadmark_w*2,0,roadmark_w,heigh))

car = pygame.image.load("car.png")
screen.blit(car, (100, 100))

while running:
    pygame.display.update()
    for event in pygame.event.get():
        keys = pygame.key.get_pressed()
        if event.type == QUIT:
            running = False
        if pygame.K_UP in keys:
            pass

pygame.quit()

